export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: { extend: {
    colors: { sun: '#F5B301', leaf: '#3F7D58', ink: '#1A1A1A', paper: '#FAF8F3' },
    fontFamily: { sans: ['"Plus Jakarta Sans"', '"Noto Sans Devanagari"', 'system-ui', 'sans-serif'] },
  } },
}
