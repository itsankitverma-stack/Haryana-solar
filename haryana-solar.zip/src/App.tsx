import { useEffect, useRef, useState, type ReactNode } from 'react'
import { Phone, MessageCircle, ArrowRight, Check, Menu, X, Sun, Home, Building2, Factory, LayoutGrid,
  ClipboardList, Ruler, PenTool, Wrench, LifeBuoy, Zap, Leaf, CalendarClock, ChevronDown, Image as Img, Upload } from 'lucide-react'
import { SITE, TEL, WA, estimateKw, submitLead } from './config'

const NAV = [['Home', '#home'], ['Solar Solutions', '#solutions'], ['How It Works', '#how'], ['Why Solar', '#why'], ['About', '#about'], ['Contact', '#contact']]
const btn = 'inline-flex items-center justify-center gap-2 rounded-full px-6 py-3.5 text-sm font-semibold transition active:scale-[.98]'
const primary = `${btn} bg-sun text-ink hover:bg-[#e0a200] group`
const ghost = `${btn} border border-ink/20 hover:border-ink hover:bg-white`
const Arrow = () => <ArrowRight size={16} className="transition group-hover:translate-x-1" />

function Reveal({ children, className = '' }: { children: ReactNode; className?: string }) {
  const r = useRef<HTMLDivElement>(null); const [v, setV] = useState(false)
  useEffect(() => { const o = new IntersectionObserver(([e]) => { if (e.isIntersecting) { setV(true); o.disconnect() } }, { threshold: .12 }); r.current && o.observe(r.current); return () => o.disconnect() }, [])
  return <div ref={r} className={`transition duration-700 ${v ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'} ${className}`}>{children}</div>
}
const Section = ({ id, children, dark = false }: { id?: string; children: ReactNode; dark?: boolean }) =>
  <section id={id} className={`py-16 md:py-24 ${dark ? 'bg-ink text-white' : ''}`}><div className="mx-auto max-w-6xl px-5">{children}</div></section>
const H2 = ({ children }: { children: ReactNode }) => <h2 className="max-w-2xl text-3xl font-extrabold leading-tight tracking-tight md:text-4xl">{children}</h2>

function Header() {
  const [open, setOpen] = useState(false)
  return <header className="sticky top-0 z-40 border-b border-ink/10 bg-paper/95 backdrop-blur">
    <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-5">
      <a href="#home" className="flex items-center gap-2 font-extrabold tracking-tight"><Sun className="text-sun" size={22} />{SITE.name}</a>
      <nav className="hidden gap-6 text-sm font-medium lg:flex" aria-label="Main">{NAV.map(([l, h]) => <a key={h} href={h} className="hover:text-leaf">{l}</a>)}</nav>
      <a href="#quote" className={`${primary} hidden !py-2.5 lg:inline-flex`}>Get Free Solar Quote</a>
      <button className="lg:hidden" onClick={() => setOpen(!open)} aria-label="Menu" aria-expanded={open}>{open ? <X /> : <Menu />}</button>
    </div>
    {open && <nav className="border-t border-ink/10 bg-paper px-5 py-3 lg:hidden" aria-label="Mobile">{NAV.map(([l, h]) => <a key={h} href={h} onClick={() => setOpen(false)} className="block py-3 font-medium">{l}</a>)}</nav>}
  </header>
}

function Hero() {
  return <section id="home" className="overflow-hidden pt-10 pb-16 md:pt-16 md:pb-24">
    <div className="mx-auto grid max-w-6xl items-center gap-10 px-5 lg:grid-cols-2">
      <div>
        <p className="text-xs font-semibold uppercase tracking-wider text-leaf">Rooftop solar solutions • Hisar &amp; Haryana</p>
        <h1 className="mt-4 text-4xl font-extrabold leading-[1.1] tracking-tight sm:text-5xl lg:text-6xl">Apni Chhat Se Bijli Bachaiye. <span className="block">Solar Par Switch Kijiye.</span></h1>
        <p className="mt-5 max-w-lg text-lg text-ink/70">Ghar, dukaan, office aur business ke liye rooftop solar solutions — site assessment se installation tak.</p>
        <div className="mt-7 flex flex-col gap-3 sm:flex-row">
          <a href="#quote" className={primary}>Get Free Solar Quote <Arrow /></a>
          <a href={TEL} className={ghost}><Phone size={16} />Talk to Solar Expert</a>
        </div>
        <ul className="mt-7 flex flex-wrap gap-x-6 gap-y-2 text-sm font-medium">{['Consultation', 'Site Assessment', 'Solar System Planning'].map(t => <li key={t} className="flex items-center gap-1.5"><Check size={16} className="text-leaf" />{t}</li>)}</ul>
      </div>
      {/* Replace this visual with an authentic Haryana Solar installation photo when available. */}
      <div className="relative mx-auto aspect-[5/4] w-full max-w-lg" role="img" aria-label="Illustration of rooftop solar panels under the sun">
        <div className="absolute right-4 top-2 h-28 w-28 rounded-full bg-sun/90 shadow-[0_0_80px_20px_rgba(245,179,1,.35)]" />
        <div className="absolute inset-x-0 bottom-0 top-16 [perspective:900px]">
          <div className="grid h-full grid-cols-6 gap-1.5 rounded-xl border border-ink bg-ink p-2 [transform:rotateX(38deg)_rotateZ(-6deg)]">
            {Array.from({ length: 24 }).map((_, i) => <div key={i} className="rounded-sm bg-gradient-to-br from-[#2b3a3a] to-[#14201f] ring-1 ring-white/10" />)}
          </div>
        </div>
      </div>
    </div>
  </section>
}

const STEPS = [[ClipboardList, 'Consultation'], [Ruler, 'Site Assessment'], [PenTool, 'System Design'], [Wrench, 'Installation'], [LifeBuoy, 'Support']] as const
function ProcessStrip() {
  return <Section><Reveal>
    <h2 className="mx-auto max-w-2xl text-center text-xl font-bold md:text-2xl">Aapke Solar Project Ko Simple Banane Ke Liye Ek Complete Process</h2>
    <ol className="mt-10 flex flex-col gap-4 md:flex-row md:items-start md:justify-between">
      {STEPS.map(([Icon, t], i) => <li key={t} className="flex items-center gap-4 md:flex-1 md:flex-col md:gap-3 md:text-center">
        <span className="relative grid h-12 w-12 shrink-0 place-items-center rounded-full bg-sun/20 text-ink"><Icon size={22} /></span>
        <span className="font-semibold">{t}</span>
        {i < 4 && <ArrowRight className="hidden text-ink/30 md:absolute md:hidden" />}
      </li>)}
    </ol>
    <div className="mt-2 hidden h-px bg-ink/15 md:block" aria-hidden />
  </Reveal></Section>
}

function Calculator() {
  const [bill, setBill] = useState(''); const [type, setType] = useState('Home'); const [kw, setKw] = useState<number | null>(null)
  return <Section id="calculator"><div className="grid gap-10 rounded-3xl bg-white p-6 ring-1 ring-ink/10 md:p-12 lg:grid-cols-2">
    <div><H2>Aapke Liye Kitna Solar Suitable Hai?</H2>
      <p className="mt-4 text-ink/70">Apna approximate monthly electricity bill enter karein aur solar requirement ka initial estimate dekhein.</p></div>
    <form onSubmit={e => { e.preventDefault(); const n = Number(bill); if (n > 0) setKw(estimateKw(n)) }} className="space-y-4">
      <Field label="Monthly Electricity Bill (₹)"><input required min={1} type="number" inputMode="numeric" value={bill} onChange={e => setBill(e.target.value)} className="inp" placeholder="e.g. 3500" /></Field>
      <Field label="Property Type"><TypeSelect value={type} onChange={setType} /></Field>
      <button className={`${primary} w-full`}>Calculate My Solar Requirement</button>
      {kw !== null && <div className="rounded-2xl bg-ink p-5 text-white" aria-live="polite">
        <p className="text-sm text-white/60">Estimated Solar Requirement ({type}) — initial estimate</p>
        <p className="mt-1 text-4xl font-extrabold text-sun">~ {kw} kW</p>
        <p className="mt-3 text-xs text-white/60">This is an initial estimate. Final capacity depends on electricity consumption, roof area, sanctioned load and site assessment.</p>
        <a href="#quote" className="mt-4 inline-block text-sm font-semibold text-sun underline">Share your bill for a proper assessment</a>
      </div>}
    </form></div>
    <style>{`.inp{width:100%;border-radius:.75rem;border:1px solid rgba(26,26,26,.2);background:#fff;padding:.8rem 1rem;font-size:1rem}.inp:focus{border-color:#F5B301}`}</style>
  </Section>
}
const Field = ({ label, children }: { label: string; children: ReactNode }) => <label className="block text-sm font-semibold"><span className="mb-1.5 block">{label}</span>{children}</label>
const TypeSelect = ({ value, onChange, opts = ['Home', 'Shop', 'Office', 'Commercial', 'Other'] }: { value: string; onChange: (v: string) => void; opts?: string[] }) =>
  <select className="inp" value={value} onChange={e => onChange(e.target.value)}>{opts.map(o => <option key={o}>{o}</option>)}</select>

const SOL = [
  [Home, 'Residential Solar', 'Rooftop solar solutions designed for homes looking to reduce dependence on grid electricity.', 'Explore Residential Solar'],
  [Building2, 'Commercial Solar', 'Solar solutions for shops, offices, schools and other commercial spaces with regular electricity consumption.', 'Explore Commercial Solar'],
  [Factory, 'Business & Industrial Solar', 'Solar system planning for businesses with higher electricity consumption.', 'Talk to an Expert'],
  [LayoutGrid, 'Rooftop Solar', 'Make better use of your available rooftop space with a properly planned solar installation.', 'Check Your Roof'],
] as const
function Solutions() {
  return <Section id="solutions"><H2>Solar Solutions For Every Need</H2>
    <div className="mt-10 grid gap-5 sm:grid-cols-2">{SOL.map(([Icon, t, d, c]) => <Reveal key={t}>
      <a href="#quote" className="group flex h-full flex-col rounded-3xl border border-ink/10 bg-white p-7 transition hover:-translate-y-1 hover:border-sun">
        <Icon className="text-leaf" size={30} /><h3 className="mt-5 text-xl font-bold">{t}</h3>
        <p className="mt-2 flex-1 text-ink/70">{d}</p>
        <span className="mt-6 inline-flex items-center gap-2 text-sm font-semibold">{c} <Arrow /></span>
      </a></Reveal>)}</div></Section>
}

const WHY = [[Zap, 'Reduce Electricity Dependence', 'Generate electricity from your own rooftop.'], [LayoutGrid, 'Better Use of Your Roof', 'Turn unused rooftop space into an energy-generating asset.'],
  [CalendarClock, 'Long-Term Energy Planning', 'Solar can help homeowners and businesses plan their electricity expenses.'], [Leaf, 'Cleaner Energy', 'Generate electricity using sunlight.']] as const
function Why() {
  return <Section id="why" dark><h2 className="max-w-2xl text-3xl font-extrabold leading-tight md:text-4xl">Solar Sirf Panel Nahi Hai. Ye Long-Term Energy Planning Hai.</h2>
    <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">{WHY.map(([Icon, t, d]) => <Reveal key={t}><div className="h-full rounded-2xl border border-white/15 p-6">
      <Icon className="text-sun" /><h3 className="mt-4 font-bold">{t}</h3><p className="mt-2 text-sm text-white/65">{d}</p></div></Reveal>)}</div>
    <a href="#quote" className={`${primary} mt-10`}>Find Out If Solar Is Right For You <Arrow /></a></Section>
}

const HOW = [['Share Your Electricity Bill', 'Apna latest electricity bill share karein.'], ['Site Assessment', 'Roof, electricity consumption aur installation requirements evaluate ki jaati hain.'],
  ['Solar System Design', 'Aapki requirement ke according suitable system plan kiya jaata hai.'], ['Installation', 'Approved plan ke according solar system installation.'], ['Commissioning & Support', 'System ko operational karne ke baad required support.']]
function How() {
  return <Section id="how"><H2>Solar Lagwana Ab Complicated Nahi.</H2>
    <ol className="relative mt-10 space-y-8 border-l-2 border-sun/50 pl-8">{HOW.map(([t, d], i) => <li key={t} className="relative">
      <span className="absolute -left-[46px] grid h-9 w-9 place-items-center rounded-full bg-sun text-sm font-bold">{String(i + 1).padStart(2, '0')}</span>
      <h3 className="text-lg font-bold">{t}</h3><p className="text-ink/70">{d}</p></li>)}</ol>
    <a href="#quote" className={`${primary} mt-10`}>Start My Solar Consultation <Arrow /></a></Section>
}

function LeadForm() {
  const [done, setDone] = useState(false); const [busy, setBusy] = useState(false); const [type, setType] = useState('Home')
  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault(); const f = new FormData(e.currentTarget); setBusy(true)
    await submitLead({ name: String(f.get('name')), mobile: String(f.get('mobile')), area: String(f.get('area')), bill: String(f.get('bill')), type, file: f.get('file') as File })
    setBusy(false); setDone(true)
  }
  return <Section id="quote"><div className="mx-auto max-w-2xl rounded-3xl bg-white p-6 ring-1 ring-ink/10 md:p-10">
    {done ? <div className="py-10 text-center" role="status"><div className="mx-auto grid h-14 w-14 place-items-center rounded-full bg-leaf text-white"><Check /></div>
      <h2 className="mt-5 text-2xl font-extrabold">Thank you!</h2><p className="mt-2 text-ink/70">Your request has been received. Our team will contact you regarding the next steps.</p></div>
    : <><h2 className="text-3xl font-extrabold md:text-4xl">Apna Electricity Bill Share Karein</h2>
      <p className="mt-2 text-ink/70">Get an Initial Solar Assessment</p>
      <form onSubmit={onSubmit} className="mt-6 grid gap-4 sm:grid-cols-2">
        <Field label="Full Name"><input required name="name" autoComplete="name" className="inp" /></Field>
        <Field label="Mobile Number"><input required name="mobile" type="tel" inputMode="tel" pattern="[0-9+\s]{10,14}" autoComplete="tel" className="inp" /></Field>
        <Field label="City / Area"><input required name="area" className="inp" placeholder="e.g. Arya Nagar, Hisar" /></Field>
        <Field label="Monthly Electricity Bill (₹)"><input required name="bill" type="number" inputMode="numeric" min={1} className="inp" /></Field>
        <div className="sm:col-span-2"><Field label="Property Type"><TypeSelect value={type} onChange={setType} opts={['Home', 'Shop', 'Office', 'Commercial']} /></Field></div>
        <label className="sm:col-span-2 flex cursor-pointer items-center gap-3 rounded-xl border border-dashed border-ink/30 p-4 text-sm font-semibold hover:border-sun">
          <Upload size={20} className="text-leaf" />Upload Electricity Bill (photo or PDF)<input name="file" type="file" accept="image/*,.pdf" className="ml-auto max-w-[45%] text-xs font-normal" /></label>
        <button disabled={busy} className={`${primary} sm:col-span-2 disabled:opacity-60`}>{busy ? 'Sending…' : <>Get My Solar Estimate <Arrow /></>}</button>
      </form></>}
  </div></Section>
}

// DEVELOPER NOTE: replace these placeholders with verified real projects and photos supplied by Haryana Solar.
const PROJ = [['Residential Rooftop', 'Hisar, Haryana'], ['Commercial Solar', 'Hisar, Haryana'], ['Rooftop Solar Project', 'Haryana']]
function Projects() {
  return <Section><H2>Solar Projects</H2><div className="mt-10 grid gap-5 md:grid-cols-3">{PROJ.map(([t, l]) => <figure key={t}>
    <div className="grid aspect-[4/3] place-items-center rounded-2xl bg-ink/[.06] text-ink/40"><Img size={36} /><span className="-mt-6 text-xs">Project photo placeholder</span></div>
    <figcaption className="mt-3 font-bold">{t}<span className="block text-sm font-normal text-ink/60">{l}</span></figcaption></figure>)}</div></Section>
}

function About() {
  return <Section id="about"><div className="grid gap-8 lg:grid-cols-2"><H2>Local Solar Expertise. Personalised Solutions.</H2>
    <div className="space-y-4 text-ink/75"><p>Haryana Solar is a solar energy company serving customers in and around Hisar, Haryana.</p>
      <p>We help homeowners and businesses understand their solar requirements and choose a solution based on their electricity consumption, property and available rooftop space.</p>
      <p>From initial consultation and system planning to installation and support, our goal is to make the transition to solar simpler and more transparent.</p></div></div></Section>
}

const FAQS = [['How do I know what size solar system I need?', 'Solar capacity depends on electricity consumption, sanctioned load, available roof area and other site conditions. A proper assessment is recommended before finalising the system.'],
  ['Can I install solar on my home?', 'Most suitable rooftops can be evaluated for solar installation. Final suitability depends on roof structure, space, orientation, shading and other site conditions.'],
  ['How much can I save with solar?', 'Savings depend on electricity consumption, system size, generation, tariff and other factors. The final assessment should be based on your electricity bill and site conditions.'],
  ['What information do you need for an initial assessment?', 'Your electricity bill, approximate location, property type and basic roof information are useful starting points.'],
  ['Do you provide installation support?', '[Confirm with Haryana Solar]'], ['Do you help with subsidy or net-metering documentation?', '[Confirm with Haryana Solar]']]
function FAQ() {
  return <Section><H2>Frequently Asked Questions</H2><div className="mt-8 max-w-3xl divide-y divide-ink/10 border-y border-ink/10">
    {FAQS.map(([q, a]) => <details key={q} className="group py-4"><summary className="flex cursor-pointer list-none items-center justify-between gap-4 font-semibold">{q}<ChevronDown size={18} className="shrink-0 transition group-open:rotate-180" /></summary><p className="mt-3 text-ink/70">{a}</p></details>)}</div></Section>
}

function FinalCTA() {
  return <Section id="contact" dark><div className="max-w-2xl"><h2 className="text-3xl font-extrabold md:text-4xl">Ready To Explore Solar For Your Property?</h2>
    <p className="mt-3 text-white/70">Share your electricity bill and let our team understand your requirement.</p>
    <div className="mt-7 flex flex-col gap-3 sm:flex-row"><a href="#quote" className={primary}>Get Free Solar Quote <Arrow /></a>
      <a href={WA} target="_blank" rel="noreferrer" className={`${btn} border border-white/30 hover:bg-white/10`}><MessageCircle size={16} />WhatsApp Haryana Solar</a></div></div></Section>
}

function Footer() {
  const L = (items: string[][]) => <ul className="mt-3 space-y-2 text-sm text-white/70">{items.map(([l, h]) => <li key={l}><a href={h} className="hover:text-sun">{l}</a></li>)}</ul>
  return <footer className="bg-ink pb-28 text-white lg:pb-10"><div className="mx-auto grid max-w-6xl gap-8 border-t border-white/10 px-5 py-12 md:grid-cols-4">
    <div className="md:col-span-1"><p className="font-extrabold">{SITE.name}</p><p className="text-sm text-white/60">Solar Energy Solutions</p>
      <address className="mt-3 text-sm not-italic text-white/70">{SITE.address}</address><a href={TEL} className="mt-2 inline-block text-sm font-semibold text-sun">{SITE.phoneDisplay}</a></div>
    <div><p className="font-semibold">Quick Links</p>{L(NAV)}</div>
    <div><p className="font-semibold">Services</p>{L([['Residential Solar', '#solutions'], ['Commercial Solar', '#solutions'], ['Rooftop Solar', '#solutions'], ['Solar Consultation', '#quote']])}</div>
    <p className="self-end text-xs text-white/50 md:col-span-1">© 2026 Haryana Solar. All Rights Reserved.</p></div></footer>
}

function Sticky() {
  const c = 'flex flex-1 flex-col items-center gap-1 py-2.5 text-xs font-semibold'
  return <>
    <nav className="fixed inset-x-0 bottom-0 z-50 flex border-t border-ink/10 bg-white pb-[env(safe-area-inset-bottom)] lg:hidden" aria-label="Quick actions">
      <a href={TEL} className={c}><Phone size={18} />Call</a><a href={WA} target="_blank" rel="noreferrer" className={c}><MessageCircle size={18} className="text-leaf" />WhatsApp</a>
      <a href="#quote" className={`${c} bg-sun`}><Sun size={18} />Get Quote</a></nav>
    <a href={WA} target="_blank" rel="noreferrer" aria-label="WhatsApp Haryana Solar" className="fixed bottom-6 right-6 z-50 hidden h-14 w-14 place-items-center rounded-full bg-[#25D366] text-white shadow-lg transition hover:scale-105 lg:grid"><MessageCircle /></a></>
}

export default function App() {
  return <><Header /><main><Hero /><ProcessStrip /><Calculator /><Solutions /><Why /><How /><LeadForm /><Projects /><About /><FAQ /><FinalCTA /></main><Footer /><Sticky /></>
}
