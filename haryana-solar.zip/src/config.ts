// Single place to edit contact details.
export const SITE = {
  name: 'HARYANA SOLAR',
  phoneDisplay: '099911 23211',
  phoneE164: '+919991123211',
  whatsappNumber: '919991123211', // country code + number, no "+"
  address: 'Kaimri–Mangali Road, near Pioneer Academy, New Mall Colony, Arya Nagar, Hisar, Haryana 125007',
  waMessage: 'Hello Haryana Solar,\nI am interested in installing solar for my property.\nI would like to know the suitable solar system for my requirement.',
}
export const TEL = `tel:${SITE.phoneE164}`
export const WA = `https://wa.me/${SITE.whatsappNumber}?text=${encodeURIComponent(SITE.waMessage)}`

/** INITIAL ESTIMATE ONLY. Assumptions (replace with verified values from the business):
 *  ~₹8 per unit average tariff, ~120 units generated per kW per month. */
export const ASSUMED_TARIFF = 8
export const UNITS_PER_KW_MONTH = 120
export function estimateKw(monthlyBill: number): number {
  const kw = monthlyBill / ASSUMED_TARIFF / UNITS_PER_KW_MONTH
  return Math.max(1, Math.round(kw * 2) / 2)
}

export type Lead = { name: string; mobile: string; area: string; bill: string; type: string; file?: File | null }
/** Demo stub. Replace with a real POST (e.g. to a Vercel /api route) later. */
export async function submitLead(_lead: Lead): Promise<void> {
  await new Promise(r => setTimeout(r, 700))
}
